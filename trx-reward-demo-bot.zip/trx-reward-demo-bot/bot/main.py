import os, sqlite3, time
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters

load_dotenv()
TOKEN=os.getenv("BOT_TOKEN")
DB="data/bot.db"
os.makedirs("data",exist_ok=True)
db=sqlite3.connect(DB,check_same_thread=False)
db.execute("""CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY, username TEXT, balance REAL DEFAULT 0,
 package TEXT, last_claim INTEGER DEFAULT 0, referrer INTEGER)""")
db.execute("""CREATE TABLE IF NOT EXISTS withdrawals(
 id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,amount REAL,address TEXT,status TEXT,created INTEGER)""")
db.commit()

# DEMO rewards only; not real investment returns.
PACKAGES={
 "starter":("Starter",25.0,0.25),
 "basic":("Basic",50.0,0.60),
 "pro":("Pro",100.0,1.20),
 "premium":("Premium",250.0,3.50),
 "vip":("VIP",500.0,7.50),
 "elite":("Elite",1000.0,16.0),
}

def user(u,ref=None):
    row=db.execute("SELECT id FROM users WHERE id=?",(u.id,)).fetchone()
    if not row:
        db.execute("INSERT INTO users(id,username,referrer) VALUES(?,?,?)",(u.id,u.username or "",ref))
        db.commit()

def menu():
    return InlineKeyboardMarkup([
      [InlineKeyboardButton("📦 Packages",callback_data="packages"),
       InlineKeyboardButton("💰 Balance",callback_data="balance")],
      [InlineKeyboardButton("🎁 Daily Claim",callback_data="claim"),
       InlineKeyboardButton("👥 Referral",callback_data="ref")],
      [InlineKeyboardButton("💸 Withdrawal Request",callback_data="withdraw")]
    ])

async def start(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    ref=None
    if ctx.args and ctx.args[0].startswith("ref_"):
        try: ref=int(ctx.args[0][4:])
        except: pass
    user(update.effective_user,ref)
    await update.message.reply_text(
      "🤖 *TRX Reward Demo*\n\n"
      "This is a simulated reward system for testing the bot UI and logic. "
      "Package rewards are not guaranteed investment returns and no real TRX is sent automatically.",
      parse_mode="Markdown",reply_markup=menu())

async def cb(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    q=update.callback_query; await q.answer(); u=q.from_user; user(u); uid=u.id
    if q.data=="packages":
        rows=[]
        for k,(n,p,r) in PACKAGES.items():
            rows.append([InlineKeyboardButton(f"{n} • ${p:.0f} • {r:.2f}/day",callback_data=f"pkg:{k}")])
        await q.edit_message_text("📦 *Demo Packages*\nChoose a package to simulate activation:",parse_mode="Markdown",
                                  reply_markup=InlineKeyboardMarkup(rows+[ [InlineKeyboardButton("⬅️ Back",callback_data="back")] ]))
    elif q.data.startswith("pkg:"):
        k=q.data.split(":")[1]; n,p,r=PACKAGES[k]
        # Demo activation: no payment is processed.
        db.execute("UPDATE users SET package=?,last_claim=0 WHERE id=?",(k,uid)); db.commit()
        await q.edit_message_text(
          f"✅ *{n} activated in DEMO mode.*\n\n"
          f"Package value: ${p:.2f}\nDaily demo reward: {r:.2f} TRX-value units\n\n"
          "No payment or real TRX transfer was made.",parse_mode="Markdown",reply_markup=menu())
    elif q.data=="balance":
        row=db.execute("SELECT balance,package FROM users WHERE id=?",(uid,)).fetchone()
        await q.edit_message_text(f"💰 Balance: `{row[0]:.6f}`\n📦 Package: `{row[1] or 'None'}`",
                                  parse_mode="Markdown",reply_markup=menu())
    elif q.data=="claim":
        row=db.execute("SELECT balance,package,last_claim FROM users WHERE id=?",(uid,)).fetchone()
        if not row[1]:
            text="❌ Activate a demo package first."
        elif int(time.time())-row[2] < 86400:
            left=86400-(int(time.time())-row[2])
            text=f"⏳ Next claim in about {left//3600}h {(left%3600)//60}m."
        else:
            reward=PACKAGES[row[1]][2]
            db.execute("UPDATE users SET balance=balance+?,last_claim=? WHERE id=?",(reward,int(time.time()),uid)); db.commit()
            text=f"🎁 Daily demo claim: +{reward:.2f}\n💰 New balance: {row[0]+reward:.2f}"
        await q.edit_message_text(text,reply_markup=menu())
    elif q.data=="ref":
        me=await ctx.bot.get_me()
        await q.edit_message_text(
          f"👥 Referral\nhttps://t.me/{me.username}?start=ref_{uid}\n\n"
          "Demo rule: referral becomes eligible only after the invited user activates a demo package.",
          reply_markup=menu())
    elif q.data=="withdraw":
        ctx.user_data["withdraw"]=True
        await q.edit_message_text("💸 Send a wallet address for a *demo withdrawal request*.",parse_mode="Markdown")
    elif q.data=="back":
        await q.edit_message_text("Main menu",reply_markup=menu())

async def text(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    if not ctx.user_data.pop("withdraw",False):
        await update.message.reply_text("Use /start.",reply_markup=menu()); return
    uid=update.effective_user.id; user(update.effective_user)
    bal=db.execute("SELECT balance FROM users WHERE id=?",(uid,)).fetchone()[0]
    address=update.message.text.strip()
    db.execute("INSERT INTO withdrawals(user_id,amount,address,status,created) VALUES(?,?,?,?,?)",
               (uid,bal,address,"demo_pending",int(time.time())))
    db.commit()
    await update.message.reply_text("📨 Demo withdrawal request saved for admin review.\nNo real TRX was transferred.",reply_markup=menu())

app=Application.builder().token(TOKEN).build()
app.add_handler(CommandHandler("start",start))
app.add_handler(CallbackQueryHandler(cb))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,text))
app.run_polling()
