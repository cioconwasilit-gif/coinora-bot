# TRX Reward Demo Telegram Bot

This is a TEST/DEMO bot. It simulates package activation, daily claims, referrals, balances and withdrawal requests.

It does NOT:
- accept real investment payments
- promise or guarantee returns
- automatically transfer TRX
- custody private keys

Run:
1. Install Python 3.11+.
2. `python -m venv .venv`
3. Windows: `.venv\Scripts\activate`
4. `pip install -r requirements.txt`
5. Copy `.env.example` to `.env` and add the BotFather token.
6. `python -m bot.main`

The package numbers are demo UI values only.
